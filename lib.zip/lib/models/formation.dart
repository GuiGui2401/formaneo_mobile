class Formation {
  final String id;
  final String title;
  final String description;
  final String category;
  final String subCategory;
  final String videoUrl;
  final String thumbnailUrl;
  final double price;
  final int duration; // en minutes
  final List<String> modules;
  final bool isPurchased;
  final double rating;
  final int studentsCount;

  Formation({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.subCategory,
    required this.videoUrl,
    required this.thumbnailUrl,
    required this.price,
    required this.duration,
    required this.modules,
    this.isPurchased = false,
    this.rating = 0.0,
    this.studentsCount = 0,
  });

  factory Formation.fromJson(Map<String, dynamic> json) {
    return Formation(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      category: json['category'],
      subCategory: json['subCategory'],
      videoUrl: json['videoUrl'],
      thumbnailUrl: json['thumbnailUrl'],
      price: json['price'].toDouble(),
      duration: json['duration'],
      modules: List<String>.from(json['modules']),
      isPurchased: json['isPurchased'] ?? false,
      rating: json['rating']?.toDouble() ?? 0.0,
      studentsCount: json['studentsCount'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'category': category,
      'subCategory': subCategory,
      'videoUrl': videoUrl,
      'thumbnailUrl': thumbnailUrl,
      'price': price,
      'duration': duration,
      'modules': modules,
      'isPurchased': isPurchased,
      'rating': rating,
      'studentsCount': studentsCount,
    };
  }
}

class FormationCategory {
  final String id;
  final String name;
  final String icon;
  final List<FormationSubCategory> subCategories;

  FormationCategory({
    required this.id,
    required this.name,
    required this.icon,
    required this.subCategories,
  });
}

class FormationSubCategory {
  final String id;
  final String name;
  final String parentCategoryId;

  FormationSubCategory({
    required this.id,
    required this.name,
    required this.parentCategoryId,
  });
}