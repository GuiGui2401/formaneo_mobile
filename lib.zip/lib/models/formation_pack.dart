class FormationPack {
  final String id;
  final String name;
  final String author;
  final String description;
  final String thumbnailUrl;
  final double price;
  final List<Formation> formations;
  final int totalDuration; // en minutes
  final double rating;
  final int studentsCount;
  final bool isPurchased;
  final DateTime? purchaseDate;
  final Map<String, double> progress; // formation_id -> progress percentage

  FormationPack({
    required this.id,
    required this.name,
    required this.author,
    required this.description,
    required this.thumbnailUrl,
    required this.price,
    required this.formations,
    required this.totalDuration,
    this.rating = 0.0,
    this.studentsCount = 0,
    this.isPurchased = false,
    this.purchaseDate,
    this.progress = const {},
  });

  factory FormationPack.fromJson(Map<String, dynamic> json) {
    return FormationPack(
      id: json['id'].toString(),
      name: json['name'] ?? '',
      author: json['author'] ?? '',
      description: json['description'] ?? '',
      thumbnailUrl: json['thumbnail_url'] ?? '',
      price: (json['price'] ?? 0).toDouble(),
      formations: (json['formations'] as List<dynamic>?)
          ?.map((f) => Formation.fromJson(f))
          .toList() ?? [],
      totalDuration: json['total_duration'] ?? 0,
      rating: (json['rating'] ?? 0).toDouble(),
      studentsCount: json['students_count'] ?? 0,
      isPurchased: json['is_purchased'] ?? false,
      purchaseDate: json['purchase_date'] != null 
          ? DateTime.parse(json['purchase_date']) 
          : null,
      progress: Map<String, double>.from(json['progress'] ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'author': author,
      'description': description,
      'thumbnail_url': thumbnailUrl,
      'price': price,
      'formations': formations.map((f) => f.toJson()).toList(),
      'total_duration': totalDuration,
      'rating': rating,
      'students_count': studentsCount,
      'is_purchased': isPurchased,
      'purchase_date': purchaseDate?.toIso8601String(),
      'progress': progress,
    };
  }

  double get completionPercentage {
    if (formations.isEmpty) return 0.0;
    
    double totalProgress = 0.0;
    for (final formation in formations) {
      totalProgress += progress[formation.id] ?? 0.0;
    }
    return totalProgress / formations.length;
  }

  int get completedFormationsCount {
    return progress.values.where((p) => p >= 100.0).length;
  }

  double get cashbackAmount => price * 0.15; // 15% de cashback
}

class Formation {
  final String id;
  final String packId;
  final String title;
  final String description;
  final int duration; // en minutes
  final List<Module> modules;
  final String videoUrl;
  final String? pdfUrl;
  final bool isCompleted;
  final double progress;

  Formation({
    required this.id,
    required this.packId,
    required this.title,
    required this.description,
    required this.duration,
    required this.modules,
    required this.videoUrl,
    this.pdfUrl,
    this.isCompleted = false,
    this.progress = 0.0,
  });

  factory Formation.fromJson(Map<String, dynamic> json) {
    return Formation(
      id: json['id'].toString(),
      packId: json['pack_id'].toString(),
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      duration: json['duration'] ?? 0,
      modules: (json['modules'] as List<dynamic>?)
          ?.map((m) => Module.fromJson(m))
          .toList() ?? [],
      videoUrl: json['video_url'] ?? '',
      pdfUrl: json['pdf_url'],
      isCompleted: json['is_completed'] ?? false,
      progress: (json['progress'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'pack_id': packId,
      'title': title,
      'description': description,
      'duration': duration,
      'modules': modules.map((m) => m.toJson()).toList(),
      'video_url': videoUrl,
      'pdf_url': pdfUrl,
      'is_completed': isCompleted,
      'progress': progress,
    };
  }
}

class Module {
  final String id;
  final String formationId;
  final String title;
  final int duration; // en minutes
  final String videoUrl;
  final bool isCompleted;
  final double progress;

  Module({
    required this.id,
    required this.formationId,
    required this.title,
    required this.duration,
    required this.videoUrl,
    this.isCompleted = false,
    this.progress = 0.0,
  });

  factory Module.fromJson(Map<String, dynamic> json) {
    return Module(
      id: json['id'].toString(),
      formationId: json['formation_id'].toString(),
      title: json['title'] ?? '',
      duration: json['duration'] ?? 0,
      videoUrl: json['video_url'] ?? '',
      isCompleted: json['is_completed'] ?? false,
      progress: (json['progress'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'formation_id': formationId,
      'title': title,
      'duration': duration,
      'video_url': videoUrl,
      'is_completed': isCompleted,
      'progress': progress,
    };
  }
}