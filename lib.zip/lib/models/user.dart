class User {
  final String id;
  final String name;
  final String email;
  final String? phone;
  final String? profileImageUrl;
  final double balance;
  final double availableForWithdrawal;
  final String promoCode;
  final String affiliateLink;
  final int totalAffiliates;
  final int monthlyAffiliates;
  final int freeQuizzesLeft;
  final DateTime createdAt;
  final DateTime? lastLoginAt;
  final bool isEmailVerified;
  final bool isPremium;
  final Map<String, dynamic>? metadata;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    this.profileImageUrl,
    this.balance = 0.0,
    this.availableForWithdrawal = 0.0,
    required this.promoCode,
    required this.affiliateLink,
    this.totalAffiliates = 0,
    this.monthlyAffiliates = 0,
    this.freeQuizzesLeft = 5,
    required this.createdAt,
    this.lastLoginAt,
    this.isEmailVerified = false,
    this.isPremium = false,
    this.metadata,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'].toString(),
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'],
      profileImageUrl: json['profile_image_url'],
      balance: (json['balance'] ?? 0).toDouble(),
      availableForWithdrawal: (json['available_for_withdrawal'] ?? 0).toDouble(),
      promoCode: json['promo_code'] ?? '',
      affiliateLink: json['affiliate_link'] ?? '',
      totalAffiliates: json['total_affiliates'] ?? 0,
      monthlyAffiliates: json['monthly_affiliates'] ?? 0,
      freeQuizzesLeft: json['free_quizzes_left'] ?? 5,
      createdAt: DateTime.parse(json['created_at']),
      lastLoginAt: json['last_login_at'] != null 
          ? DateTime.parse(json['last_login_at']) 
          : null,
      isEmailVerified: json['is_email_verified'] ?? false,
      isPremium: json['is_premium'] ?? false,
      metadata: json['metadata'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'profile_image_url': profileImageUrl,
      'balance': balance,
      'available_for_withdrawal': availableForWithdrawal,
      'promo_code': promoCode,
      'affiliate_link': affiliateLink,
      'total_affiliates': totalAffiliates,
      'monthly_affiliates': monthlyAffiliates,
      'free_quizzes_left': freeQuizzesLeft,
      'created_at': createdAt.toIso8601String(),
      'last_login_at': lastLoginAt?.toIso8601String(),
      'is_email_verified': isEmailVerified,
      'is_premium': isPremium,
      'metadata': metadata,
    };
  }

  User copyWith({
    String? id,
    String? name,
    String? email,
    String? phone,
    String? profileImageUrl,
    double? balance,
    double? availableForWithdrawal,
    String? promoCode,
    String? affiliateLink,
    int? totalAffiliates,
    int? monthlyAffiliates,
    int? freeQuizzesLeft,
    DateTime? createdAt,
    DateTime? lastLoginAt,
    bool? isEmailVerified,
    bool? isPremium,
    Map<String, dynamic>? metadata,
  }) {
    return User(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      balance: balance ?? this.balance,
      availableForWithdrawal: availableForWithdrawal ?? this.availableForWithdrawal,
      promoCode: promoCode ?? this.promoCode,
      affiliateLink: affiliateLink ?? this.affiliateLink,
      totalAffiliates: totalAffiliates ?? this.totalAffiliates,
      monthlyAffiliates: monthlyAffiliates ?? this.monthlyAffiliates,
      freeQuizzesLeft: freeQuizzesLeft ?? this.freeQuizzesLeft,
      createdAt: createdAt ?? this.createdAt,
      lastLoginAt: lastLoginAt ?? this.lastLoginAt,
      isEmailVerified: isEmailVerified ?? this.isEmailVerified,
      isPremium: isPremium ?? this.isPremium,
      metadata: metadata ?? this.metadata,
    );
  }
}