class Quiz {
  final String id;
  final String title;
  final String subject;
  final String difficulty;
  final List<QuizQuestion> questions;
  final int duration; // en secondes
  final int passingScore; // pourcentage minimum pour réussir

  Quiz({
    required this.id,
    required this.title,
    required this.subject,
    required this.difficulty,
    required this.questions,
    this.duration = 300, // 5 minutes par défaut
    this.passingScore = 60,
  });

  factory Quiz.fromJson(Map<String, dynamic> json) {
    return Quiz(
      id: json['id']?.toString() ?? '',
      title: json['title'] ?? '',
      subject: json['subject'] ?? '',
      difficulty: json['difficulty'] ?? 'moyen',
      questions: (json['questions'] as List<dynamic>?)
          ?.map((q) => QuizQuestion.fromJson(q))
          .toList() ?? [],
      duration: json['duration'] ?? 300,
      passingScore: json['passing_score'] ?? 60,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'subject': subject,
      'difficulty': difficulty,
      'questions': questions.map((q) => q.toJson()).toList(),
      'duration': duration,
      'passing_score': passingScore,
    };
  }
}

class QuizQuestion {
  final String id;
  final String question;
  final List<String> options;
  final int correctAnswer;
  final String? explanation;

  QuizQuestion({
    required this.id,
    required this.question,
    required this.options,
    required this.correctAnswer,
    this.explanation,
  });

  factory QuizQuestion.fromJson(Map<String, dynamic> json) {
    return QuizQuestion(
      id: json['id']?.toString() ?? '',
      question: json['question'] ?? '',
      options: List<String>.from(json['options'] ?? []),
      correctAnswer: json['correct_answer'] ?? 0,
      explanation: json['explanation'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'question': question,
      'options': options,
      'correct_answer': correctAnswer,
      'explanation': explanation,
    };
  }
}

class QuizResult {
  final String id;
  final Quiz quiz;
  final List<int> userAnswers;
  final int score;
  final double percentage;
  final bool isPassed;
  final double rewardEarned;
  final DateTime completedAt;
  final int totalQuestions;

  QuizResult({
    required this.id,
    required this.quiz,
    required this.userAnswers,
    required this.score,
    required this.percentage,
    required this.isPassed,
    required this.rewardEarned,
    required this.completedAt,
    required this.totalQuestions,
  });

  factory QuizResult.fromJson(Map<String, dynamic> json) {
    return QuizResult(
      id: json['id']?.toString() ?? '',
      quiz: Quiz.fromJson(json['quiz']),
      userAnswers: List<int>.from(json['user_answers'] ?? []),
      score: json['score'] ?? 0,
      percentage: (json['percentage'] ?? 0).toDouble(),
      isPassed: json['is_passed'] ?? false,
      rewardEarned: (json['reward_earned'] ?? 0).toDouble(),
      completedAt: DateTime.parse(json['completed_at']),
      totalQuestions: json['total_questions'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'quiz': quiz.toJson(),
      'user_answers': userAnswers,
      'score': score,
      'percentage': percentage,
      'is_passed': isPassed,
      'reward_earned': rewardEarned,
      'completed_at': completedAt.toIso8601String(),
      'total_questions': totalQuestions,
    };
  }
}