import 'package:flutter/foundation.dart';
import '../services/affiliate_service.dart';

class AffiliateProvider extends ChangeNotifier {
  Map<String, double> _earnings = {
    'today': 0.0,
    'yesterday': 0.0,
    'currentMonth': 0.0,
    'lastMonth': 0.0,
    'total': 0.0,
  };

  Map<String, int> _stats = {
    'totalAffiliates': 0,
    'monthlyAffiliates': 0,
    'activeAffiliates': 0,
  };

  String _affiliateLink = '';
  String _promoCode = '';
  bool _isLoading = false;
  List<Map<String, dynamic>> _affiliatesList = [];

  Map<String, double> get earnings => _earnings;
  Map<String, int> get stats => _stats;
  String get affiliateLink => _affiliateLink;
  String get promoCode => _promoCode;
  bool get isLoading => _isLoading;
  List<Map<String, dynamic>> get affiliatesList => _affiliatesList;

  Future<void> loadAffiliateData() async {
    _isLoading = true;
    notifyListeners();

    try {
      final data = await AffiliateService.getAffiliateData();
      
      _earnings = {
        'today': data['earnings']['today']?.toDouble() ?? 0.0,
        'yesterday': data['earnings']['yesterday']?.toDouble() ?? 0.0,
        'currentMonth': data['earnings']['current_month']?.toDouble() ?? 0.0,
        'lastMonth': data['earnings']['last_month']?.toDouble() ?? 0.0,
        'total': data['earnings']['total']?.toDouble() ?? 0.0,
      };

      _stats = {
        'totalAffiliates': data['stats']['total_affiliates'] ?? 0,
        'monthlyAffiliates': data['stats']['monthly_affiliates'] ?? 0,
        'activeAffiliates': data['stats']['active_affiliates'] ?? 0,
      };

      _affiliateLink = data['affiliate_link'] ?? '';
      _promoCode = data['promo_code'] ?? '';
      _affiliatesList = List<Map<String, dynamic>>.from(data['affiliates_list'] ?? []);
      
    } catch (e) {
      print('Erreur lors du chargement des données d\'affiliation: $e');
      // Utiliser des données fictives en cas d'erreur
      _loadMockData();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void _loadMockData() {
    _earnings = {
      'today': 2500.00,
      'yesterday': 11878.00,
      'currentMonth': 51660.00,
      'lastMonth': 31700.00,
      'total': 115566.00,
    };

    _stats = {
      'totalAffiliates': 66,
      'monthlyAffiliates': 20,
      'activeAffiliates': 43,
    };

    _affiliateLink = 'https://formaneo.app/invite/WB001';
    _promoCode = 'WB001';
  }

  double getCommissionRate() {
    if (_stats['monthlyAffiliates']! > 100) {
      return 2500.00; // Premium
    }
    return 2000.00; // Basic
  }

  void addAffiliate(Map<String, dynamic> affiliate) {
    _affiliatesList.insert(0, affiliate);
    _stats['totalAffiliates'] = (_stats['totalAffiliates'] ?? 0) + 1;
    _stats['monthlyAffiliates'] = (_stats['monthlyAffiliates'] ?? 0) + 1;
    notifyListeners();
  }
}