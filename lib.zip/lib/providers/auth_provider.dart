import 'package:flutter/foundation.dart';
import '../models/user.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  User? _currentUser;
  bool _isAuthenticated = false;
  bool _isLoading = false;
  String? _authToken;

  User? get currentUser => _currentUser;
  bool get isAuthenticated => _isAuthenticated;
  bool get isLoading => _isLoading;
  String? get authToken => _authToken;

  Future<void> loadUserData() async {
    _isLoading = true;
    notifyListeners();

    try {
      final userData = await AuthService.getCurrentUser();
      if (userData != null) {
        _currentUser = userData;
        _isAuthenticated = true;
        _authToken = await AuthService.getToken();
      }
    } catch (e) {
      print('Erreur lors du chargement des données utilisateur: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> login(String email, String password) async {
    _isLoading = true;
    notifyListeners();

    try {
      final result = await AuthService.login(email, password);
      if (result.isSuccess) {
        _currentUser = result.user;
        _isAuthenticated = true;
        _authToken = result.token;
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print('Erreur de connexion: $e');
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> register({
    required String name,
    required String email,
    required String password,
    String? promoCode,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      final result = await AuthService.register(
        name: name,
        email: email,
        password: password,
        promoCode: promoCode,
      );
      
      if (result.isSuccess) {
        _currentUser = result.user;
        _isAuthenticated = true;
        _authToken = result.token;
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print('Erreur d\'inscription: $e');
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    await AuthService.logout();
    _currentUser = null;
    _isAuthenticated = false;
    _authToken = null;
    notifyListeners();
  }

  void updateUser(User user) {
    _currentUser = user;
    notifyListeners();
  }
}