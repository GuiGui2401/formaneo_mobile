import 'package:flutter/foundation.dart';
import '../models/quiz.dart';
import '../services/quiz_service.dart';

class QuizProvider extends ChangeNotifier {
  List<Quiz> _quizzes = [];
  Quiz? _currentQuiz;
  int _freeQuizzesLeft = 5;
  bool _isLoading = false;
  Map<String, List<QuizResult>> _quizHistory = {};
  
  List<Quiz> get quizzes => _quizzes;
  Quiz? get currentQuiz => _currentQuiz;
  int get freeQuizzesLeft => _freeQuizzesLeft;
  bool get isLoading => _isLoading;
  Map<String, List<QuizResult>> get quizHistory => _quizHistory;

  Future<void> loadQuizzes() async {
    _isLoading = true;
    notifyListeners();

    try {
      _quizzes = await QuizService.getAvailableQuizzes();
      _freeQuizzesLeft = await QuizService.getFreeQuizzesLeft();
    } catch (e) {
      print('Erreur lors du chargement des quiz: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<Quiz?> generateQuiz(String subject, int numberOfQuestions, String difficulty) async {
    if (_freeQuizzesLeft <= 0) return null;
    
    _isLoading = true;
    notifyListeners();

    try {
      final quizData = await QuizService.generateQuiz(
        subject: subject,
        numberOfQuestions: numberOfQuestions,
        difficulty: difficulty,
      );
      
      if (quizData != null) {
        _currentQuiz = Quiz.fromJson(quizData);
        _freeQuizzesLeft--;
        notifyListeners();
        return _currentQuiz;
      }
    } catch (e) {
      print('Erreur lors de la génération du quiz: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
    
    return null;
  }

  Future<void> submitQuizResult(QuizResult result) async {
    try {
      await QuizService.saveQuizResult(result);
      
      // Ajouter à l'historique
      final subject = result.quiz.subject;
      if (!_quizHistory.containsKey(subject)) {
        _quizHistory[subject] = [];
      }
      _quizHistory[subject]!.add(result);
      
      notifyListeners();
    } catch (e) {
      print('Erreur lors de la sauvegarde du résultat: $e');
    }
  }

  void resetCurrentQuiz() {
    _currentQuiz = null;
    notifyListeners();
  }
}