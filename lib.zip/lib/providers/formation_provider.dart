import 'package:flutter/foundation.dart';
import '../models/formation_pack.dart';
import '../services/formation_service.dart';

class FormationProvider extends ChangeNotifier {
  List<FormationPack> _formationPacks = [];
  FormationPack? _currentPack;
  Formation? _currentFormation;
  Module? _currentModule;
  bool _isLoading = false;
  Map<String, double> _progress = {};

  List<FormationPack> get formationPacks => _formationPacks;
  FormationPack? get currentPack => _currentPack;
  Formation? get currentFormation => _currentFormation;
  Module? get currentModule => _currentModule;
  bool get isLoading => _isLoading;
  Map<String, double> get progress => _progress;

  Future<void> loadFormationPacks() async {
    _isLoading = true;
    notifyListeners();

    try {
      _formationPacks = await FormationService.getFormationPacks();
      
      // Si aucun pack n'est retourné par l'API, utiliser les packs par défaut
      if (_formationPacks.isEmpty) {
        _formationPacks = _getDefaultPacks();
      }
    } catch (e) {
      print('Erreur lors du chargement des packs: $e');
      // Utiliser les packs par défaut en cas d'erreur
      _formationPacks = _getDefaultPacks();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> purchasePack(String packId) async {
    _isLoading = true;
    notifyListeners();

    try {
      final success = await FormationService.purchasePack(packId);
      if (success) {
        await loadFormationPacks();
      }
      return success;
    } catch (e) {
      print('Erreur lors de l\'achat du pack: $e');
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void selectPack(FormationPack pack) {
    _currentPack = pack;
    notifyListeners();
  }

  void selectFormation(Formation formation) {
    _currentFormation = formation;
    notifyListeners();
  }

  void selectModule(Module module) {
    _currentModule = module;
    notifyListeners();
  }

  Future<void> updateProgress(String formationId, double progressValue) async {
    _progress[formationId] = progressValue;
    
    // Mettre à jour le progress dans le pack actuel
    if (_currentPack != null) {
      final packIndex = _formationPacks.indexWhere((p) => p.id == _currentPack!.id);
      if (packIndex != -1) {
        _formationPacks[packIndex].progress[formationId] = progressValue;
      }
    }
    
    notifyListeners();

    // Sauvegarder en base de données
    try {
      await FormationService.updateProgress(formationId, progressValue);
      
      // Si la formation est complétée (100%), déclencher le cashback
      if (progressValue >= 100.0) {
        await _triggerCashback(formationId);
      }
    } catch (e) {
      print('Erreur lors de la mise à jour du progrès: $e');
    }
  }

  Future<void> _triggerCashback(String formationId) async {
    try {
      await FormationService.claimCashback(formationId);
      // Le cashback sera géré par le WalletProvider
    } catch (e) {
      print('Erreur lors du déclenchement du cashback: $e');
    }
  }

  List<FormationPack> _getDefaultPacks() {
    return [
      FormationPack(
        id: '1',
        name: 'Dropskills - Pack de Formations',
        author: 'Cédric D.',
        description: 'Pack complet de 27 formations sur le dropshipping, e-commerce et marketing digital.',
        thumbnailUrl: '',
        price: 50000.00,
        formations: _getDropskillsFormations(),
        totalDuration: 2400,
        rating: 4.8,
        studentsCount: 1250,
      ),
      FormationPack(
        id: '2',
        name: 'Business Mastery - Pack Complet',
        author: 'Jonathan G.',
        description: '15 formations complètes pour maîtriser le business en ligne.',
        thumbnailUrl: '',
        price: 45000.00,
        formations: _getBusinessMasteryFormations(),
        totalDuration: 1800,
        rating: 4.9,
        studentsCount: 890,
      ),
    ];
  }

  List<Formation> _getDropskillsFormations() {
    List<Formation> formations = [];
    final titles = [
      'Introduction au Dropshipping',
      'Analyse de marché avancée',
      'Sélection de produits gagnants',
      'Création de boutique Shopify optimisée',
      'Facebook Ads Mastery',
      'Google Ads pour E-commerce',
      'TikTok Ads Strategy',
      'Email Marketing Automation',
      'Copywriting pour convertir',
      'Gestion des fournisseurs',
      'Service client excellence',
      'Optimisation du taux de conversion',
      'Scaling et automatisation',
      'Analyse des métriques',
      'Gestion financière e-commerce',
      'Branding et storytelling',
      'Influencer Marketing',
      'SEO pour e-commerce',
      'Retargeting avancé',
      'Upsell et cross-sell strategies',
      'Gestion des retours et SAV',
      'International dropshipping',
      'Print on demand mastery',
      'Subscription box business',
      'Mobile commerce optimization',
      'Voice commerce trends',
      'Sustainable e-commerce',
    ];
    
    for (int i = 0; i < titles.length; i++) {
      formations.add(Formation(
        id: 'dropskills_${i + 1}',
        packId: '1',
        title: titles[i],
        description: 'Formation complète sur ${titles[i].toLowerCase()}',
        duration: 90 + (i * 5),
        modules: _generateModules(5 + (i % 3), 'dropskills_${i + 1}'),
        videoUrl: '',
      ));
    }
    
    return formations;
  }

  List<Formation> _getBusinessMasteryFormations() {
    final formationsData = [
      {'title': 'Dropshipping 2025', 'modules': 10},
      {'title': 'Affiliation 2025', 'modules': 7},
      {'title': 'Closing Mastery', 'modules': 8},
      {'title': 'Google Ads 2025', 'modules': 8},
      {'title': 'Coaching HT', 'modules': 9},
      {'title': 'Meta Ads', 'modules': 7},
      {'title': 'Personal Branding', 'modules': 6},
      {'title': 'Tunnels de Vente 2.0', 'modules': 10},
      {'title': 'Créer un site Shopify qui convertit', 'modules': 6},
      {'title': 'Marketing par e-mail', 'modules': 8},
      {'title': 'Trouver un produit gagnant', 'modules': 2},
      {'title': 'Capcut 2025', 'modules': 7},
      {'title': 'Canva 2025', 'modules': 10},
      {'title': 'ChatGPT 2025', 'modules': 5},
      {'title': 'Growth Hacking', 'modules': 8},
    ];

    List<Formation> formations = [];
    for (int i = 0; i < formationsData.length; i++) {
      formations.add(Formation(
        id: 'bm_${i + 1}',
        packId: '2',
        title: formationsData[i]['title'] as String,
        description: 'Formation complète sur ${formationsData[i]['title']}',
        duration: (formationsData[i]['modules'] as int) * 60,
        modules: _generateModules(formationsData[i]['modules'] as int, 'bm_${i + 1}'),
        videoUrl: '',
      ));
    }
    
    return formations;
  }

  List<Module> _generateModules(int count, String formationId) {
    List<Module> modules = [];
    for (int i = 0; i < count; i++) {
      modules.add(Module(
        id: '${formationId}_module_${i + 1}',
        formationId: formationId,
        title: 'Module ${i + 1}',
        duration: 30 + (i * 5),
        videoUrl: '',
      ));
    }
    return modules;
  }
}