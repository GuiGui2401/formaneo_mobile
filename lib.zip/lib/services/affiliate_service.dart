import '../config/api_config.dart';
import 'api_service.dart';

class AffiliateService {
  // Obtenir les données d'affiliation
  static Future<Map<String, dynamic>> getAffiliateData() async {
    try {
      final response = await ApiService.get('${ApiConfig.affiliateEndpoint}/dashboard');
      
      return {
        'earnings': response['earnings'] ?? {},
        'stats': response['stats'] ?? {},
        'affiliate_link': response['affiliate_link'] ?? '',
        'promo_code': response['promo_code'] ?? '',
        'affiliates_list': response['affiliates_list'] ?? [],
      };
    } catch (e) {
      // Retourner des données fictives en cas d'erreur
      return _getMockData();
    }
  }
  
  // Obtenir la liste des affiliés
  static Future<List<Map<String, dynamic>>> getAffiliates({
    int page = 1,
    int limit = 20,
  }) async {
    try {
      final response = await ApiService.get(
        '${ApiConfig.affiliateEndpoint}/list?page=$page&limit=$limit',
      );
      
      if (response['affiliates'] != null) {
        return List<Map<String, dynamic>>.from(response['affiliates']);
      }
      
      return [];
    } catch (e) {
      return [];
    }
  }
  
  // Obtenir les statistiques détaillées
  static Future<Map<String, dynamic>> getDetailedStats() async {
    try {
      final response = await ApiService.get('${ApiConfig.affiliateEndpoint}/stats');
      
      return {
        'clicks': response['clicks'] ?? 0,
        'conversions': response['conversions'] ?? 0,
        'conversion_rate': response['conversion_rate'] ?? 0.0,
        'average_commission': response['average_commission'] ?? 0.0,
        'top_performers': response['top_performers'] ?? [],
      };
    } catch (e) {
      return {
        'clicks': 0,
        'conversions': 0,
        'conversion_rate': 0.0,
        'average_commission': 0.0,
        'top_performers': [],
      };
    }
  }
  
  // Générer un nouveau lien d'affiliation
  static Future<String?> generateNewLink(String? campaign) async {
    try {
      final response = await ApiService.post(
        '${ApiConfig.affiliateEndpoint}/generate-link',
        {
          'campaign': campaign,
        },
      );
      
      return response['link'];
    } catch (e) {
      return null;
    }
  }
  
  // Obtenir les bannières promotionnelles
  static Future<List<Map<String, dynamic>>> getPromoBanners() async {
    try {
      final response = await ApiService.get('${ApiConfig.affiliateEndpoint}/banners');
      
      if (response['banners'] != null) {
        return List<Map<String, dynamic>>.from(response['banners']);
      }
      
      return _getDefaultBanners();
    } catch (e) {
      return _getDefaultBanners();
    }
  }
  
  // Télécharger une bannière
  static Future<String?> downloadBanner(String bannerId) async {
    try {
      final response = await ApiService.get(
        '${ApiConfig.affiliateEndpoint}/banners/$bannerId/download',
      );
      
      return response['download_url'];
    } catch (e) {
      return null;
    }
  }
  
  // Obtenir l'historique des commissions
  static Future<List<Map<String, dynamic>>> getCommissionHistory({
    int page = 1,
    int limit = 20,
  }) async {
    try {
      final response = await ApiService.get(
        '${ApiConfig.affiliateEndpoint}/commissions?page=$page&limit=$limit',
      );
      
      if (response['commissions'] != null) {
        return List<Map<String, dynamic>>.from(response['commissions']);
      }
      
      return [];
    } catch (e) {
      return [];
    }
  }
  
  // Données fictives par défaut
  static Map<String, dynamic> _getMockData() {
    return {
      'earnings': {
        'today': 2500.00,
        'yesterday': 11878.00,
        'current_month': 51660.00,
        'last_month': 31700.00,
        'total': 115566.00,
      },
      'stats': {
        'total_affiliates': 66,
        'monthly_affiliates': 20,
        'active_affiliates': 43,
      },
      'affiliate_link': 'https://formaneo.app/invite/WB001',
      'promo_code': 'WB001',
      'affiliates_list': [
        {
          'name': 'Marie K.',
          'joined_date': '2025-01-15',
          'status': 'active',
          'commission_earned': 2000.00,
        },
        {
          'name': 'Paul B.',
          'joined_date': '2025-01-14',
          'status': 'active',
          'commission_earned': 2500.00,
        },
      ],
    };
  }
  
  static List<Map<String, dynamic>> _getDefaultBanners() {
    return [
      {
        'id': '1',
        'name': 'Bannière Instagram',
        'size': '1080x1080',
        'format': 'jpg',
        'url': 'https://formaneo.app/banners/instagram.jpg',
      },
      {
        'id': '2',
        'name': 'Bannière Facebook',
        'size': '1200x630',
        'format': 'jpg',
        'url': 'https://formaneo.app/banners/facebook.jpg',
      },
      {
        'id': '3',
        'name': 'Bannière Twitter',
        'size': '1024x512',
        'format': 'jpg',
        'url': 'https://formaneo.app/banners/twitter.jpg',
      },
      {
        'id': '4',
        'name': 'Story Instagram/Facebook',
        'size': '1080x1920',
        'format': 'jpg',
        'url': 'https://formaneo.app/banners/story.jpg',
      },
    ];
  }
}