import '../models/quiz.dart';
import '../config/api_config.dart';
import 'api_service.dart';

class QuizService {
  // Obtenir les quiz disponibles
  static Future<List<Quiz>> getAvailableQuizzes() async {
    try {
      final response = await ApiService.get('${ApiConfig.quizEndpoint}/available');
      
      if (response['quizzes'] != null) {
        return (response['quizzes'] as List)
            .map((q) => Quiz.fromJson(q))
            .toList();
      }
      
      return [];
    } catch (e) {
      print('Erreur lors du chargement des quiz: $e');
      return [];
    }
  }
  
  // Obtenir le nombre de quiz gratuits restants
  static Future<int> getFreeQuizzesLeft() async {
    try {
      final response = await ApiService.get('${ApiConfig.quizEndpoint}/free-count');
      return response['free_quizzes_left'] ?? 0;
    } catch (e) {
      return 5; // Valeur par défaut
    }
  }
  
  // Générer un quiz
  static Future<Map<String, dynamic>?> generateQuiz({
    required String subject,
    required int numberOfQuestions,
    required String difficulty,
  }) async {
    try {
      // Pour l'instant, retourner un quiz fictif
      return {
        'quiz': {
          'id': DateTime.now().millisecondsSinceEpoch.toString(),
          'title': 'Quiz $subject',
          'subject': subject,
          'difficulty': difficulty,
          'questions': _generateMockQuestions(subject, numberOfQuestions),
        }
      };
    } catch (e) {
      print('Erreur lors de la génération du quiz: $e');
      return null;
    }
  }
  
  // Sauvegarder le résultat d'un quiz
  static Future<bool> saveQuizResult(QuizResult result) async {
    try {
      final response = await ApiService.post(
        '${ApiConfig.quizEndpoint}/results',
        result.toJson(),
      );
      
      return response['success'] == true;
    } catch (e) {
      print('Erreur lors de la sauvegarde du résultat: $e');
      return false;
    }
  }
  
  // Obtenir l'historique des quiz
  static Future<List<QuizResult>> getQuizHistory({int page = 1, int limit = 20}) async {
    try {
      final response = await ApiService.get(
        '${ApiConfig.quizEndpoint}/history?page=$page&limit=$limit',
      );
      
      if (response['results'] != null) {
        return (response['results'] as List)
            .map((r) => QuizResult.fromJson(r))
            .toList();
      }
      
      return [];
    } catch (e) {
      return [];
    }
  }
  
  // Obtenir les statistiques des quiz
  static Future<Map<String, dynamic>> getQuizStats() async {
    try {
      final response = await ApiService.get('${ApiConfig.quizEndpoint}/stats');
      
      return {
        'total_quizzes': response['total_quizzes'] ?? 0,
        'passed_quizzes': response['passed_quizzes'] ?? 0,
        'average_score': response['average_score'] ?? 0.0,
        'total_rewards': response['total_rewards'] ?? 0.0,
      };
    } catch (e) {
      return {
        'total_quizzes': 0,
        'passed_quizzes': 0,
        'average_score': 0.0,
        'total_rewards': 0.0,
      };
    }
  }
  
  // Générer des questions fictives pour les tests
  static List<Map<String, dynamic>> _generateMockQuestions(String subject, int count) {
    final questions = <Map<String, dynamic>>[];
    
    for (int i = 0; i < count; i++) {
      questions.add({
        'id': 'q${i + 1}',
        'question': _getQuestionBySubject(subject, i),
        'options': _getOptionsBySubject(subject, i),
        'correct_answer': i % 4,
        'explanation': 'Explication de la réponse correcte.',
      });
    }
    
    return questions;
  }
  
  static String _getQuestionBySubject(String subject, int index) {
    final questions = {
      'Culture générale': [
        'Quelle est la capitale de la France ?',
        'Qui a peint la Joconde ?',
        'En quelle année a eu lieu la Révolution française ?',
        'Quel est le plus grand océan du monde ?',
        'Combien y a-t-il de continents ?',
      ],
      'Mathématiques': [
        'Quelle est la dérivée de x² ?',
        'Résoudre: 2x + 5 = 13',
        'Calculer le périmètre d\'un cercle de rayon 5',
        'Quelle est la formule du théorème de Pythagore ?',
        'Combien vaut la somme des angles d\'un triangle ?',
      ],
      'Physique': [
        'Quelle est la vitesse de la lumière ?',
        'Qui a découvert la gravité ?',
        'Quelle est l\'unité de force ?',
        'Que mesure un voltmètre ?',
        'Quelle est la formule de l\'énergie cinétique ?',
      ],
      'Informatique': [
        'Que signifie HTML ?',
        'Quel langage est utilisé pour Flutter ?',
        'Qu\'est-ce qu\'un algorithme ?',
        'Que signifie API ?',
        'Qu\'est-ce que le cloud computing ?',
      ],
    };
    
    final subjectQuestions = questions[subject] ?? questions['Culture générale']!;
    return subjectQuestions[index % subjectQuestions.length];
  }
  
  static List<String> _getOptionsBySubject(String subject, int index) {
    final options = {
      'Culture générale': [
        ['Paris', 'Londres', 'Berlin', 'Madrid'],
        ['Léonard de Vinci', 'Picasso', 'Van Gogh', 'Monet'],
        ['1789', '1792', '1804', '1815'],
        ['Pacifique', 'Atlantique', 'Indien', 'Arctique'],
        ['5', '6', '7', '8'],
      ],
      'Mathématiques': [
        ['2x', 'x', '2', 'x²'],
        ['x = 4', 'x = 3', 'x = 5', 'x = 6'],
        ['10π', '25π', '5π', '2π'],
        ['a² + b² = c²', 'a + b = c', 'a² - b² = c²', 'a × b = c²'],
        ['180°', '360°', '90°', '270°'],
      ],
    };
    
    final subjectOptions = options[subject] ?? options['Culture générale']!;
    return subjectOptions[index % subjectOptions.length];
  }
}