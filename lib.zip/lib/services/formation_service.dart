import '../models/formation_pack.dart';
import '../config/api_config.dart';
import 'api_service.dart';

class FormationService {
  // Obtenir tous les packs de formations
  static Future<List<FormationPack>> getFormationPacks() async {
    try {
      final response = await ApiService.get(ApiConfig.packsEndpoint);
      
      if (response['packs'] != null) {
        return (response['packs'] as List)
            .map((p) => FormationPack.fromJson(p))
            .toList();
      }
      
      return [];
    } catch (e) {
      print('Erreur lors du chargement des packs: $e');
      return [];
    }
  }
  
  // Obtenir un pack spécifique
  static Future<FormationPack?> getPackById(String packId) async {
    try {
      final response = await ApiService.get('${ApiConfig.packsEndpoint}/$packId');
      
      if (response['pack'] != null) {
        return FormationPack.fromJson(response['pack']);
      }
      
      return null;
    } catch (e) {
      return null;
    }
  }
  
  // Acheter un pack
  static Future<bool> purchasePack(String packId) async {
    try {
      final response = await ApiService.post(
        '${ApiConfig.packsEndpoint}/$packId/purchase',
        {},
      );
      
      return response['success'] == true;
    } catch (e) {
      return false;
    }
  }
  
  // Obtenir les formations d'un pack
  static Future<List<Formation>> getPackFormations(String packId) async {
    try {
      final response = await ApiService.get(
        '${ApiConfig.packsEndpoint}/$packId/formations',
      );
      
      if (response['formations'] != null) {
        return (response['formations'] as List)
            .map((f) => Formation.fromJson(f))
            .toList();
      }
      
      return [];
    } catch (e) {
      return [];
    }
  }
  
  // Obtenir une formation spécifique
  static Future<Formation?> getFormationById(String formationId) async {
    try {
      final response = await ApiService.get(
        '${ApiConfig.formationsEndpoint}/$formationId',
      );
      
      if (response['formation'] != null) {
        return Formation.fromJson(response['formation']);
      }
      
      return null;
    } catch (e) {
      return null;
    }
  }
  
  // Mettre à jour le progrès d'une formation
  static Future<bool> updateProgress(String formationId, double progress) async {
    try {
      final response = await ApiService.put(
        '${ApiConfig.formationsEndpoint}/$formationId/progress',
        {'progress': progress},
      );
      
      return response['success'] == true;
    } catch (e) {
      return false;
    }
  }
  
  // Marquer un module comme complété
  static Future<bool> completeModule(String moduleId) async {
    try {
      final response = await ApiService.post(
        '${ApiConfig.formationsEndpoint}/modules/$moduleId/complete',
        {},
      );
      
      return response['success'] == true;
    } catch (e) {
      return false;
    }
  }
  
  // Réclamer le cashback d'une formation
  static Future<bool> claimCashback(String formationId) async {
    try {
      final response = await ApiService.post(
        '${ApiConfig.formationsEndpoint}/$formationId/cashback',
        {},
      );
      
      return response['success'] == true;
    } catch (e) {
      return false;
    }
  }
  
  // Obtenir les statistiques de progression
  static Future<Map<String, dynamic>> getProgressStats() async {
    try {
      final response = await ApiService.get(
        '${ApiConfig.formationsEndpoint}/stats',
      );
      
      return {
        'total_formations': response['total_formations'] ?? 0,
        'completed_formations': response['completed_formations'] ?? 0,
        'total_hours': response['total_hours'] ?? 0,
        'certificates_earned': response['certificates_earned'] ?? 0,
        'total_cashback': response['total_cashback'] ?? 0.0,
      };
    } catch (e) {
      return {
        'total_formations': 0,
        'completed_formations': 0,
        'total_hours': 0,
        'certificates_earned': 0,
        'total_cashback': 0.0,
      };
    }
  }
  
  // Télécharger le certificat d'une formation
  static Future<String?> downloadCertificate(String formationId) async {
    try {
      final response = await ApiService.get(
        '${ApiConfig.formationsEndpoint}/$formationId/certificate',
      );
      
      return response['certificate_url'];
    } catch (e) {
      return null;
    }
  }
  
  // Obtenir les notes d'une formation
  static Future<List<Map<String, dynamic>>> getFormationNotes(String formationId) async {
    try {
      final response = await ApiService.get(
        '${ApiConfig.formationsEndpoint}/$formationId/notes',
      );
      
      if (response['notes'] != null) {
        return List<Map<String, dynamic>>.from(response['notes']);
      }
      
      return [];
    } catch (e) {
      return [];
    }
  }
  
  // Ajouter une note à une formation
  static Future<bool> addNote(String formationId, String note, String timestamp) async {
    try {
      final response = await ApiService.post(
        '${ApiConfig.formationsEndpoint}/$formationId/notes',
        {
          'note': note,
          'timestamp': timestamp,
        },
      );
      
      return response['success'] == true;
    } catch (e) {
      return false;
    }
  }
}