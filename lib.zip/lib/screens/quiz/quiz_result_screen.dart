import 'package:flutter/material.dart';
import '../../models/quiz.dart';
import '../../config/theme.dart';
import '../../services/quiz_service.dart';

class QuizResultScreen extends StatefulWidget {
  final QuizResult result;

  const QuizResultScreen({Key? key, required this.result}) : super(key: key);

  @override
  _QuizResultScreenState createState() => _QuizResultScreenState();
}

class _QuizResultScreenState extends State<QuizResultScreen>
    with TickerProviderStateMixin {
  late AnimationController _scoreAnimationController;
  late AnimationController _confettiController;
  late Animation<double> _scoreAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _saveResult();
  }

  void _initializeAnimations() {
    _scoreAnimationController = AnimationController(
      duration: Duration(milliseconds: 1500),
      vsync: this,
    );

    _confettiController = AnimationController(
      duration: Duration(milliseconds: 2000),
      vsync: this,
    );

    _scoreAnimation = Tween<double>(
      begin: 0,
      end: widget.result.percentage,
    ).animate(CurvedAnimation(
      parent: _scoreAnimationController,
      curve: Curves.easeOutCubic,
    ));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _scoreAnimationController,
      curve: Interval(0.5, 1.0, curve: Curves.easeIn),
    ));

    _scoreAnimationController.forward();
    
    if (widget.result.isPassed) {
      Future.delayed(Duration(milliseconds: 800), () {
        _confettiController.forward();
      });
    }
  }

  void _saveResult() async {
    try {
      await QuizService.saveQuizResult(widget.result);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur lors de la sauvegarde: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(AppSpacing.lg),
            child: Column(
              children: [
                SizedBox(height: AppSpacing.lg),
                _buildResultHeader(),
                SizedBox(height: AppSpacing.xl),
                _buildScoreCircle(),
                SizedBox(height: AppSpacing.xl),
                _buildResultDetails(),
                SizedBox(height: AppSpacing.lg),
                _buildRewardCard(),
                SizedBox(height: AppSpacing.lg),
                _buildQuestionReview(),
                SizedBox(height: AppSpacing.xl),
                _buildActionButtons(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResultHeader() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Column(
        children: [
          Icon(
            widget.result.isPassed ? Icons.emoji_events : Icons.thumb_up,
            size: 80,
            color: widget.result.isPassed ? Colors.amber : AppTheme.primaryColor,
          ),
          SizedBox(height: AppSpacing.md),
          Text(
            widget.result.isPassed ? 'Félicitations !' : 'Bien essayé !',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: AppTheme.textPrimary,
            ),
          ),
          SizedBox(height: AppSpacing.sm),
          Text(
            widget.result.isPassed 
                ? 'Vous avez réussi le quiz !'
                : 'Continuez vos efforts, vous progressez !',
            style: TextStyle(
              fontSize: 16,
              color: AppTheme.textSecondary,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildScoreCircle() {
    return AnimatedBuilder(
      animation: _scoreAnimation,
      builder: (context, child) {
        return Container(
          width: 200,
          height: 200,
          child: Stack(
            children: [
              // Cercle de fond
              Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 20,
                      offset: Offset(0, 10),
                    ),
                  ],
                ),
              ),
              
              // Indicateur de progression circulaire
              SizedBox(
                width: 200,
                height: 200,
                child: CircularProgressIndicator(
                  value: _scoreAnimation.value / 100,
                  strokeWidth: 8,
                  backgroundColor: Color(0xFFE2E8F0),
                  valueColor: AlwaysStoppedAnimation<Color>(
                    widget.result.isPassed ? AppTheme.accentColor : Colors.orange,
                  ),
                ),
              ),
              
              // Score au centre
              Container(
                width: 200,
                height: 200,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '${_scoreAnimation.value.round()}%',
                        style: TextStyle(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: widget.result.isPassed ? AppTheme.accentColor : Colors.orange,
                        ),
                      ),
                      Text(
                        '${widget.result.score}/${widget.result.totalQuestions}',
                        style: TextStyle(
                          fontSize: 16,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildResultDetails() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Container(
        padding: EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppBorderRadius.lg),
          border: Border.all(color: Color(0xFFE2E8F0)),
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildDetailItem(
                  'Bonnes réponses',
                  '${widget.result.score}',
                  AppTheme.accentColor,
                  Icons.check_circle,
                ),
                _buildDetailItem(
                  'Mauvaises réponses',
                  '${widget.result.totalQuestions - widget.result.score}',
                  Colors.red,
                  Icons.cancel,
                ),
              ],
            ),
            SizedBox(height: AppSpacing.lg),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildDetailItem(
                  'Temps écoulé',
                  '${DateTime.now().difference(widget.result.completedAt.subtract(Duration(minutes: 5))).inMinutes} min',
                  AppTheme.primaryColor,
                  Icons.access_time,
                ),
                _buildDetailItem(
                  'Statut',
                  widget.result.isPassed ? 'Réussi' : 'Échoué',
                  widget.result.isPassed ? AppTheme.accentColor : Colors.orange,
                  widget.result.isPassed ? Icons.emoji_events : Icons.refresh,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value, Color color, IconData icon) {
    return Column(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(AppBorderRadius.md),
          ),
          child: Icon(icon, color: color, size: 24),
        ),
        SizedBox(height: AppSpacing.sm),
        Text(
          value,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: AppTheme.textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildRewardCard() {
    if (widget.result.rewardEarned <= 0) return SizedBox.shrink();

    return FadeTransition(
      opacity: _fadeAnimation,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [AppTheme.accentColor, AppTheme.accentColor.withOpacity(0.8)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(AppBorderRadius.lg),
          boxShadow: [
            BoxShadow(
              color: AppTheme.accentColor.withOpacity(0.3),
              blurRadius: 20,
              offset: Offset(0, 10),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.monetization_on,
                color: Colors.white,
                size: 30,
              ),
            ),
            SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Récompense gagnée !',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '+${widget.result.rewardEarned.toStringAsFixed(0)} FCFA ajoutés à votre solde',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestionReview() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Container(
        padding: EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppBorderRadius.lg),
          border: Border.all(color: Color(0xFFE2E8F0)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Révision des questions',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            SizedBox(height: AppSpacing.md),
            ...widget.result.quiz.questions.asMap().entries.map((entry) {
              int index = entry.key;
              QuizQuestion question = entry.value;
              bool isCorrect = widget.result.userAnswers[index] == question.correctAnswer;
              
              return _buildQuestionSummary(
                index + 1,
                question,
                widget.result.userAnswers[index],
                isCorrect,
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestionSummary(
    int questionNumber,
    QuizQuestion question,
    int userAnswer,
    bool isCorrect,
  ) {
    return Container(
      margin: EdgeInsets.only(bottom: AppSpacing.md),
      padding: EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: isCorrect 
            ? AppTheme.accentColor.withOpacity(0.05)
            : Colors.red.withOpacity(0.05),
        borderRadius: BorderRadius.circular(AppBorderRadius.md),
        border: Border.all(
          color: isCorrect 
              ? AppTheme.accentColor.withOpacity(0.3)
              : Colors.red.withOpacity(0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: isCorrect ? AppTheme.accentColor : Colors.red,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  isCorrect ? Icons.check : Icons.close,
                  color: Colors.white,
                  size: 16,
                ),
              ),
              SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Text(
                  'Question $questionNumber',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimary,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: AppSpacing.sm),
          Text(
            question.question,
            style: TextStyle(
              fontSize: 14,
              color: AppTheme.textPrimary,
            ),
          ),
          SizedBox(height: AppSpacing.sm),
          Text(
            'Votre réponse: ${question.options[userAnswer]}',
            style: TextStyle(
              fontSize: 12,
              color: isCorrect ? AppTheme.accentColor : Colors.red,
              fontWeight: FontWeight.w500,
            ),
          ),
          if (!isCorrect) ...[
            Text(
              'Bonne réponse: ${question.options[question.correctAnswer]}',
              style: TextStyle(
                fontSize: 12,
                color: AppTheme.accentColor,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Column(
      children: [
        Container(
          width: double.infinity,
          height: 56,
          child: ElevatedButton(
            onPressed: _retryQuiz,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
            ),
            child: Text(
              'Refaire le quiz',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
        SizedBox(height: AppSpacing.md),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: _shareResult,
                child: Text('Partager'),
              ),
            ),
            SizedBox(width: AppSpacing.md),
            Expanded(
              child: OutlinedButton(
                onPressed: _goHome,
                child: Text('Accueil'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _retryQuiz() {
    Navigator.pop(context);
    // Relancer un quiz du même sujet
  }

  void _shareResult() {
    final message = 'Je viens de scorer ${widget.result.percentage}% au quiz "${widget.result.quiz.title}" sur Formaneo ! 🎉';
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Résultat copié pour partage !'),
        backgroundColor: AppTheme.accentColor,
      ),
    );
  }

  void _goHome() {
    Navigator.pushNamedAndRemoveUntil(
      context,
      '/home',
      (route) => false,
    );
  }

  @override
  void dispose() {
    _scoreAnimationController.dispose();
    _confettiController.dispose();
    super.dispose();
  }
}