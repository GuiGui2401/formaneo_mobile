import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import 'package:provider/provider.dart';
import '../../config/theme.dart';
import '../../config/constants.dart';
import '../../providers/auth_provider.dart';
import '../../providers/wallet_provider.dart';
import '../../utils/formatters.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _scrollController = ScrollController();
  Timer? _notificationTimer;
  int _currentNotificationIndex = 0;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _startNotificationRotation();
    _loadData();
  }

  void _startNotificationRotation() {
    _notificationTimer = Timer.periodic(Duration(seconds: 3), (timer) {
      if (mounted) {
        setState(() {
          _currentNotificationIndex =
              (_currentNotificationIndex + 1) %
              FictiveNotifications.notifications.length;
        });
      }
    });
  }

  void _loadData() async {
    setState(() => _isLoading = true);

    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final walletProvider = Provider.of<WalletProvider>(context, listen: false);

    await Future.wait([
      authProvider.loadUserData(),
      walletProvider.loadBalance(),
    ]);

    setState(() => _isLoading = false);
  }

  Future<void> _handleRefresh() async {
    _loadData();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final walletProvider = Provider.of<WalletProvider>(context);
    final user = authProvider.currentUser;

    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _handleRefresh,
          child: CustomScrollView(
            controller: _scrollController,
            physics: AlwaysScrollableScrollPhysics(),
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.all(AppSpacing.md),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildHeader(user?.name ?? 'Utilisateur'),
                      SizedBox(height: AppSpacing.lg),
                      _buildBalanceCard(walletProvider.balance),
                      SizedBox(height: AppSpacing.lg),
                      _buildWithdrawalAvailability(walletProvider.balance),
                      SizedBox(height: AppSpacing.lg),
                      _buildNotificationBar(),
                      SizedBox(height: AppSpacing.lg),
                      _buildServicesGrid(),
                      SizedBox(height: AppSpacing.lg),
                      _buildRecentActivity(),
                      SizedBox(height: AppSpacing.xxl),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(String userName) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            CircleAvatar(
              radius: 28,
              backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
              child: Icon(Icons.person, color: AppTheme.primaryColor, size: 28),
            ),
            SizedBox(width: AppSpacing.md),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Bonjour,',
                  style: TextStyle(fontSize: 14, color: AppTheme.textSecondary),
                ),
                Text(
                  userName,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.textPrimary,
                  ),
                ),
              ],
            ),
          ],
        ),
        Row(
          children: [
            IconButton(
              onPressed: _showNotifications,
              icon: Stack(
                children: [
                  Icon(
                    Icons.notifications_outlined,
                    size: 28,
                    color: AppTheme.textSecondary,
                  ),
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: AppTheme.errorColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildBalanceCard(double balance) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.primaryColor,
            AppTheme.primaryColor.withOpacity(0.8),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppBorderRadius.lg),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withOpacity(0.3),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.account_balance_wallet, color: Colors.white, size: 24),
              SizedBox(width: AppSpacing.sm),
              Text(
                'Solde du compte',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 14,
                ),
              ),
            ],
          ),
          SizedBox(height: AppSpacing.md),
          Text(
            Formatters.formatAmount(balance),
            style: TextStyle(
              color: Colors.white,
              fontSize: 32,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWithdrawalAvailability(double balance) {
    final canWithdraw = balance >= AppConstants.minWithdrawalAmount;

    return Container(
      padding: EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: canWithdraw
            ? AppTheme.accentColor.withOpacity(0.1)
            : Colors.grey.withOpacity(0.1),
        borderRadius: BorderRadius.circular(AppBorderRadius.md),
        border: Border.all(
          color: canWithdraw
              ? AppTheme.accentColor
              : Colors.grey.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.info_outline,
            color: canWithdraw ? AppTheme.accentColor : Colors.grey,
            size: 20,
          ),
          SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  canWithdraw
                      ? 'Disponible pour retrait'
                      : 'Retrait non disponible',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: canWithdraw ? AppTheme.accentColor : Colors.grey,
                  ),
                ),
                Text(
                  canWithdraw
                      ? 'Vous pouvez retirer vos gains'
                      : 'Minimum requis: ${Formatters.formatAmount(AppConstants.minWithdrawalAmount)}',
                  style: TextStyle(
                    fontSize: 12,
                    color: canWithdraw ? AppTheme.textSecondary : Colors.grey,
                  ),
                ),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: canWithdraw ? _showWithdrawDialog : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: canWithdraw ? AppTheme.accentColor : Colors.grey,
              padding: EdgeInsets.symmetric(
                horizontal: AppSpacing.md,
                vertical: AppSpacing.sm,
              ),
            ),
            child: Text('Retirer', style: TextStyle(fontSize: 14)),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationBar() {
    final notification =
        FictiveNotifications.notifications[_currentNotificationIndex];

    return AnimatedSwitcher(
      duration: Duration(milliseconds: 500),
      child: Container(
        key: ValueKey(_currentNotificationIndex),
        padding: EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: Colors.orange.withOpacity(0.1),
          borderRadius: BorderRadius.circular(AppBorderRadius.md),
          border: Border.all(color: Colors.orange.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(Icons.campaign, color: Colors.orange, size: 20),
            SizedBox(width: AppSpacing.md),
            Expanded(
              child: Text(
                '🎉 ${notification['name']} ${notification['action']} ${notification['amount']} ${notification['source']}',
                style: TextStyle(color: Colors.orange[800], fontSize: 13),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildServicesGrid() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Nos Services', style: Theme.of(context).textTheme.headlineMedium),
        SizedBox(height: AppSpacing.md),
        GridView.count(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          crossAxisCount: 3,
          mainAxisSpacing: AppSpacing.md,
          crossAxisSpacing: AppSpacing.md,
          childAspectRatio: 0.9,
          children: [
            _buildServiceCard(
              'Quiz Rémunérés',
              'Testez vos connaissances',
              AppTheme.primaryColor,
              Icons.quiz,
              () => Navigator.pushNamed(context, '/quiz'),
            ),
            _buildServiceCard(
              'Formations',
              'Packs de formations',
              AppTheme.primaryColor,
              Icons.school,
              () => Navigator.pushNamed(context, '/formations'),
            ),
            _buildServiceCard(
              'Ebooks',
              'Bibliothèque numérique',
              AppTheme.primaryColor,
              Icons.menu_book,
              () => _showComingSoon('Ebooks'),
            ),
            _buildServiceCard(
              'Programme d\'Affiliation',
              'Invitez et gagnez',
              AppTheme.primaryColor,
              Icons.people,
              () => Navigator.pushNamed(context, '/affiliate'),
            ),
            _buildServiceCard(
              'Défis & Récompenses',
              'Participez aux défis',
              AppTheme.primaryColor,
              Icons.emoji_events,
              () => _showDefisModal(),
            ),
            _buildServiceCard(
              'Mes Cartes Bancaires',
              'Bientôt disponible',
              AppTheme.primaryColor,
              Icons.credit_card,
              () => _showComingSoon('Mes Cartes Bancaires'),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildServiceCard(
    String title,
    String subtitle,
    Color color,
    IconData icon,
    VoidCallback onTap,
  ) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppBorderRadius.lg),
        child: Container(
          padding: EdgeInsets.all(AppSpacing.md),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(AppBorderRadius.md),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              SizedBox(height: AppSpacing.sm),
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimary,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(fontSize: 10, color: AppTheme.textSecondary),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecentActivity() {
    final activities = [
      {
        'title': 'Bonus d\'inscription reçu',
        'amount': '+1,000.00 FCFA',
        'date': '10/11/2025',
      },
      {
        'title': 'Cashback formation',
        'amount': '+500.00 FCFA',
        'date': '09/11/2025',
      },
      {
        'title': 'Bonus quiz réussi',
        'amount': '+100.00 FCFA',
        'date': '08/11/2025',
      },
      {
        'title': 'Commission affiliation',
        'amount': '+2,000.00 FCFA',
        'date': '07/11/2025',
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Activité récente',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            TextButton(
              onPressed: () => Navigator.pushNamed(context, '/transactions'),
              child: Text('Voir tout'),
            ),
          ],
        ),
        SizedBox(height: AppSpacing.md),
        Container(
          padding: EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppBorderRadius.lg),
            border: Border.all(color: Color(0xFFE2E8F0)),
          ),
          child: Column(
            children: activities.map((activity) {
              return _buildActivityItem(
                activity['title'] as String,
                activity['amount'] as String,
                activity['date'] as String,
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildActivityItem(String title, String amount, String date) {
    return Container(
      margin: EdgeInsets.only(bottom: AppSpacing.md),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: AppTheme.primaryColor,
              shape: BoxShape.circle,
            ),
          ),
          SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.textPrimary,
                  ),
                ),
                Text(
                  date,
                  style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                ),
              ],
            ),
          ),
          Text(
            amount,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: AppTheme.accentColor,
            ),
          ),
        ],
      ),
    );
  }

  void _showNotifications() {
    // Implémenter l'affichage des notifications
  }

  void _showWithdrawDialog() {
    // Implémenter le dialog de retrait
  }

  void _showDefisModal() {
    // Implémenter le modal des défis
  }

  void _showComingSoon(String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$feature - Fonctionnalité bientôt disponible !'),
        backgroundColor: AppTheme.primaryColor,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  void dispose() {
    _notificationTimer?.cancel();
    _scrollController.dispose();
    super.dispose();
  }
}
