import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math' as math;
import '../../config/theme.dart';
import '../../services/auth_service.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late List<AnimationController> _iconControllers;
  late List<Animation<double>> _fillAnimations;
  late AnimationController _logoController;
  late Animation<double> _logoScale;
  
  final List<IconData> academicIcons = [
    Icons.school,
    Icons.menu_book,
    Icons.psychology,
    Icons.science,
    Icons.calculate,
    Icons.history_edu,
  ];
  
  final List<IconData> financialIcons = [
    Icons.account_balance_wallet,
    Icons.monetization_on,
    Icons.trending_up,
    Icons.attach_money,
    Icons.credit_card,
    Icons.savings,
  ];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _startApp();
  }

  void _initializeAnimations() {
    // Initialiser les contrôleurs pour chaque icône
    _iconControllers = List.generate(
      12, // 6 académiques + 6 financières
      (index) => AnimationController(
        duration: Duration(milliseconds: 500 + (index * 100)),
        vsync: this,
      ),
    );
    
    // Créer les animations de remplissage
    _fillAnimations = _iconControllers.map((controller) {
      return Tween<double>(
        begin: 0.0,
        end: 1.0,
      ).animate(CurvedAnimation(
        parent: controller,
        curve: Curves.easeInOut,
      ));
    }).toList();
    
    // Animation du logo principal
    _logoController = AnimationController(
      duration: Duration(milliseconds: 1500),
      vsync: this,
    );
    
    _logoScale = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoController,
      curve: Curves.elasticOut,
    ));
    
    // Démarrer les animations en cascade
    _startIconAnimations();
  }

  void _startIconAnimations() async {
    for (int i = 0; i < _iconControllers.length; i++) {
      await Future.delayed(Duration(milliseconds: 150));
      if (mounted) {
        _iconControllers[i].forward();
      }
    }
    
    // Animer le logo principal après les icônes
    await Future.delayed(Duration(milliseconds: 300));
    if (mounted) {
      _logoController.forward();
    }
  }

  void _startApp() async {
    try {
      // Vérifier si l'utilisateur est déjà connecté
      final isLoggedIn = await AuthService.checkSession();
      
      // Attendre la fin des animations
      await Future.delayed(Duration(seconds: 3));
      
      if (mounted) {
        if (isLoggedIn) {
          Navigator.pushReplacementNamed(context, '/main');
        } else {
          Navigator.pushReplacementNamed(context, '/login');
        }
      }
    } catch (e) {
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/login');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppTheme.primaryColor,
              AppTheme.primaryColor.withOpacity(0.8),
            ],
          ),
        ),
        child: Stack(
          children: [
            // Icônes animées en arrière-plan
            _buildAnimatedIcons(),
            
            // Logo et texte principal au centre
            Center(
              child: ScaleTransition(
                scale: _logoScale,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(AppBorderRadius.xl),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 30,
                            offset: Offset(0, 15),
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.school,
                        size: 60,
                        color: AppTheme.primaryColor,
                      ),
                    ),
                    SizedBox(height: AppSpacing.xl),
                    Text(
                      'FORMANEO',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 3,
                      ),
                    ),
                    SizedBox(height: AppSpacing.md),
                    Text(
                      'Apprenez et Gagnez',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.9),
                        fontSize: 16,
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            // Indicateur de progression en bas
            Positioned(
              bottom: 80,
              left: 0,
              right: 0,
              child: Center(
                child: Container(
                  width: 200,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(2),
                  ),
                  child: AnimatedBuilder(
                    animation: _fillAnimations.last,
                    builder: (context, child) {
                      return FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: _fillAnimations.last.value,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimatedIcons() {
    return Stack(
      children: [
        // Icônes académiques (côté gauche)
        ...List.generate(6, (index) {
          final angle = (index * math.pi / 3) - math.pi / 2;
          final radius = 150.0;
          final centerX = MediaQuery.of(context).size.width / 2 - 100;
          final centerY = MediaQuery.of(context).size.height / 2;
          
          return Positioned(
            left: centerX + radius * math.cos(angle) - 25,
            top: centerY + radius * math.sin(angle) - 25,
            child: AnimatedBuilder(
              animation: _fillAnimations[index],
              builder: (context, child) {
                return Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Stack(
                    children: [
                      // Fond rempli progressivement
                      Positioned.fill(
                        child: FractionallySizedBox(
                          alignment: Alignment.bottomCenter,
                          heightFactor: _fillAnimations[index].value,
                          child: Container(
                            decoration: BoxDecoration(
                              color: AppTheme.accentColor.withOpacity(0.3),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                      // Icône
                      Center(
                        child: Icon(
                          academicIcons[index],
                          color: Colors.white.withOpacity(0.8 + (_fillAnimations[index].value * 0.2)),
                          size: 24,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        }),
        
        // Icônes financières (côté droit)
        ...List.generate(6, (index) {
          final angle = (index * math.pi / 3) - math.pi / 2;
          final radius = 150.0;
          final centerX = MediaQuery.of(context).size.width / 2 + 100;
          final centerY = MediaQuery.of(context).size.height / 2;
          
          return Positioned(
            left: centerX + radius * math.cos(angle) - 25,
            top: centerY + radius * math.sin(angle) - 25,
            child: AnimatedBuilder(
              animation: _fillAnimations[index + 6],
              builder: (context, child) {
                return Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Stack(
                    children: [
                      // Fond rempli progressivement
                      Positioned.fill(
                        child: FractionallySizedBox(
                          alignment: Alignment.bottomCenter,
                          heightFactor: _fillAnimations[index + 6].value,
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.amber.withOpacity(0.3),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                      // Icône
                      Center(
                        child: Icon(
                          financialIcons[index],
                          color: Colors.white.withOpacity(0.8 + (_fillAnimations[index + 6].value * 0.2)),
                          size: 24,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        }),
      ],
    );
  }

  @override
  void dispose() {
    for (var controller in _iconControllers) {
      controller.dispose();
    }
    _logoController.dispose();
    super.dispose();
  }
}