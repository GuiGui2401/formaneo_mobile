import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../config/theme.dart';
import '../../providers/formation_provider.dart';
import '../../models/formation_pack.dart';
import '../../utils/formatters.dart';
import 'pack_detail_screen.dart';

class FormationPacksScreen extends StatefulWidget {
  @override
  _FormationPacksScreenState createState() => _FormationPacksScreenState();
}

class _FormationPacksScreenState extends State<FormationPacksScreen> {
  bool _isLoading = false;
  
  @override
  void initState() {
    super.initState();
    _loadPacks();
  }
  
  Future<void> _loadPacks() async {
    setState(() => _isLoading = true);
    
    final provider = Provider.of<FormationProvider>(context, listen: false);
    await provider.loadFormationPacks();
    
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    final formationProvider = Provider.of<FormationProvider>(context);
    
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: Text('Packs de Formations'),
        elevation: 0,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadPacks,
              child: SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.all(AppSpacing.md),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeader(),
                    SizedBox(height: AppSpacing.lg),
                    _buildPacksList(formationProvider.formationPacks),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.primaryColor, AppTheme.primaryColor.withOpacity(0.8)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppBorderRadius.lg),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.school, color: Colors.white, size: 32),
              SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Formations Premium',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'Accédez à des packs complets',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.9),
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: AppSpacing.md),
          Container(
            padding: EdgeInsets.all(AppSpacing.sm),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(AppBorderRadius.sm),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: Colors.white, size: 16),
                SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    '15% de cashback à la fin de chaque formation complétée !',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPacksList(List<FormationPack> packs) {
    // Créer les deux packs par défaut si la liste est vide
    if (packs.isEmpty) {
      packs = _getDefaultPacks();
    }
    
    return Column(
      children: packs.map((pack) => _buildPackCard(pack)).toList(),
    );
  }

  Widget _buildPackCard(FormationPack pack) {
    return Container(
      margin: EdgeInsets.only(bottom: AppSpacing.lg),
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => PackDetailScreen(pack: pack),
              ),
            );
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  Container(
                    height: 200,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          pack.name.contains('Dropskills') 
                              ? Colors.purple 
                              : Colors.orange,
                          pack.name.contains('Dropskills') 
                              ? Colors.purple.withOpacity(0.7) 
                              : Colors.orange.withOpacity(0.7),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.play_circle_fill,
                          color: Colors.white,
                          size: 64,
                        ),
                        SizedBox(height: AppSpacing.md),
                        Text(
                          pack.name,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (pack.isPurchased)
                    Positioned(
                      top: AppSpacing.md,
                      right: AppSpacing.md,
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: AppSpacing.md,
                          vertical: AppSpacing.sm,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.accentColor,
                          borderRadius: BorderRadius.circular(AppBorderRadius.xl),
                        ),
                        child: Text(
                          'Acheté',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              Padding(
                padding: EdgeInsets.all(AppSpacing.md),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
                          child: Icon(
                            Icons.person,
                            size: 16,
                            color: AppTheme.primaryColor,
                          ),
                        ),
                        SizedBox(width: AppSpacing.sm),
                        Text(
                          'Par ${pack.author}',
                          style: TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: AppSpacing.md),
                    Text(
                      pack.description,
                      style: TextStyle(
                        fontSize: 14,
                        color: AppTheme.textPrimary,
                        height: 1.4,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: AppSpacing.md),
                    Row(
                      children: [
                        _buildInfoChip(
                          Icons.video_library,
                          '${pack.formations.length} formations',
                        ),
                        SizedBox(width: AppSpacing.md),
                        _buildInfoChip(
                          Icons.access_time,
                          Formatters.formatDuration(pack.totalDuration),
                        ),
                        Spacer(),
                        if (!pack.isPurchased)
                          Text(
                            Formatters.formatAmount(pack.price),
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: AppTheme.accentColor,
                            ),
                          )
                        else
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: AppSpacing.md,
                              vertical: AppSpacing.sm,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.primaryColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(AppBorderRadius.md),
                            ),
                            child: Row(
                              children: [
                                CircularProgressIndicator(
                                  value: pack.completionPercentage / 100,
                                  strokeWidth: 2,
                                  backgroundColor: Colors.grey[300],
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    AppTheme.primaryColor,
                                  ),
                                ),
                                SizedBox(width: AppSpacing.sm),
                                Text(
                                  '${pack.completionPercentage.toStringAsFixed(0)}%',
                                  style: TextStyle(
                                    color: AppTheme.primaryColor,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                    if (pack.isPurchased) ...[
                      SizedBox(height: AppSpacing.md),
                      LinearProgressIndicator(
                        value: pack.completionPercentage / 100,
                        backgroundColor: Colors.grey[200],
                        valueColor: AlwaysStoppedAnimation<Color>(AppTheme.accentColor),
                      ),
                      SizedBox(height: AppSpacing.sm),
                      Text(
                        '${pack.completedFormationsCount}/${pack.formations.length} formations complétées',
                        style: TextStyle(
                          fontSize: 12,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: 4,
      ),
      decoration: BoxDecoration(
        color: AppTheme.backgroundColor,
        borderRadius: BorderRadius.circular(AppBorderRadius.sm),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: AppTheme.textSecondary),
          SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  List<FormationPack> _getDefaultPacks() {
    return [
      FormationPack(
        id: '1',
        name: 'Dropskills - Pack de Formations',
        author: 'Cédric D.',
        description: 'Pack complet de 27 formations sur le dropshipping, e-commerce et marketing digital. Apprenez les stratégies qui fonctionnent vraiment.',
        thumbnailUrl: '',
        price: 50000.00,
        formations: _getDropskillsFormations(),
        totalDuration: 2400,
        rating: 4.8,
        studentsCount: 1250,
      ),
      FormationPack(
        id: '2',
        name: 'Business Mastery - Pack Complet',
        author: 'Jonathan G.',
        description: '15 formations complètes pour maîtriser le business en ligne : dropshipping, affiliation, closing, publicité, coaching et plus.',
        thumbnailUrl: '',
        price: 45000.00,
        formations: _getBusinessMasteryFormations(),
        totalDuration: 1800,
        rating: 4.9,
        studentsCount: 890,
      ),
    ];
  }

  List<Formation> _getDropskillsFormations() {
    // Retourner 27 formations pour le pack Dropskills
    List<Formation> formations = [];
    final titles = [
      'Introduction au Dropshipping',
      'Analyse de marché avancée',
      'Sélection de produits gagnants',
      'Création de boutique Shopify optimisée',
      'Facebook Ads Mastery',
      'Google Ads pour E-commerce',
      'TikTok Ads Strategy',
      'Email Marketing Automation',
      'Copywriting pour convertir',
      'Gestion des fournisseurs',
      'Service client excellence',
      'Optimisation du taux de conversion',
      'Scaling et automatisation',
      'Analyse des métriques',
      'Gestion financière e-commerce',
      'Branding et storytelling',
      'Influencer Marketing',
      'SEO pour e-commerce',
      'Retargeting avancé',
      'Upsell et cross-sell strategies',
      'Gestion des retours et SAV',
      'International dropshipping',
      'Print on demand mastery',
      'Subscription box business',
      'Mobile commerce optimization',
      'Voice commerce trends',
      'Sustainable e-commerce',
    ];
    
    for (int i = 0; i < titles.length; i++) {
      formations.add(Formation(
        id: 'dropskills_${i + 1}',
        packId: '1',
        title: titles[i],
        description: 'Formation complète sur ${titles[i].toLowerCase()}',
        duration: 90 + (i * 5),
        modules: _generateModules(5 + (i % 3)),
        videoUrl: '',
      ));
    }
    
    return formations;
  }

  List<Formation> _getBusinessMasteryFormations() {
    return [
      Formation(
        id: 'bm_1',
        packId: '2',
        title: 'Dropshipping 2025',
        description: 'Maîtrisez le dropshipping de A à Z avec les dernières stratégies',
        duration: 600,
        modules: _generateModules(10),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_2',
        packId: '2',
        title: 'Affiliation 2025',
        description: 'Devenez un expert en marketing d\'affiliation',
        duration: 420,
        modules: _generateModules(7),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_3',
        packId: '2',
        title: 'Closing Mastery',
        description: 'Techniques avancées de closing et de vente',
        duration: 480,
        modules: _generateModules(8),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_4',
        packId: '2',
        title: 'Google Ads 2025',
        description: 'Publicité Google Ads pour maximiser votre ROI',
        duration: 480,
        modules: _generateModules(8),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_5',
        packId: '2',
        title: 'Coaching HT',
        description: 'Créez et développez votre business de coaching',
        duration: 540,
        modules: _generateModules(9),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_6',
        packId: '2',
        title: 'Meta Ads',
        description: 'Facebook et Instagram Ads pour votre business',
        duration: 420,
        modules: _generateModules(7),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_7',
        packId: '2',
        title: 'Personal Branding',
        description: 'Construisez votre marque personnelle',
        duration: 360,
        modules: _generateModules(6),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_8',
        packId: '2',
        title: 'Tunnels de Vente 2.0',
        description: 'Créez des tunnels de vente qui convertissent',
        duration: 600,
        modules: _generateModules(10),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_9',
        packId: '2',
        title: 'Créer un site Shopify qui convertit',
        description: 'Boutique Shopify optimisée pour la conversion',
        duration: 360,
        modules: _generateModules(6),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_10',
        packId: '2',
        title: 'Marketing par e-mail',
        description: 'Email marketing pour fidéliser et vendre',
        duration: 480,
        modules: _generateModules(8),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_11',
        packId: '2',
        title: 'Trouver un produit gagnant',
        description: 'Méthodes pour identifier les produits rentables',
        duration: 120,
        modules: _generateModules(2),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_12',
        packId: '2',
        title: 'Capcut 2025',
        description: 'Montage vidéo professionnel avec Capcut',
        duration: 420,
        modules: _generateModules(7),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_13',
        packId: '2',
        title: 'Canva 2025',
        description: 'Design graphique professionnel avec Canva',
        duration: 600,
        modules: _generateModules(10),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_14',
        packId: '2',
        title: 'ChatGPT 2025',
        description: 'IA et automatisation pour votre business',
        duration: 300,
        modules: _generateModules(5),
        videoUrl: '',
      ),
      Formation(
        id: 'bm_15',
        packId: '2',
        title: 'Growth Hacking',
        description: 'Techniques de croissance rapide',
        duration: 480,
        modules: _generateModules(8),
        videoUrl: '',
      ),
    ];
  }

  List<Module> _generateModules(int count) {
    List<Module> modules = [];
    for (int i = 0; i < count; i++) {
      modules.add(Module(
        id: 'module_${i + 1}',
        formationId: '',
        title: 'Module ${i + 1}',
        duration: 30 + (i * 5),
        videoUrl: '',
      ));
    }
    return modules;
  }
}