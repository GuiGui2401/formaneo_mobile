import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../config/theme.dart';
import '../../models/formation_pack.dart';
import '../../providers/formation_provider.dart';
import '../../providers/wallet_provider.dart';
import '../../utils/formatters.dart';
import '../../widgets/ai_assistant/ai_assistant_modal.dart';
import 'formation_player_screen.dart';

class PackDetailScreen extends StatefulWidget {
  final FormationPack pack;

  const PackDetailScreen({Key? key, required this.pack}) : super(key: key);

  @override
  _PackDetailScreenState createState() => _PackDetailScreenState();
}

class _PackDetailScreenState extends State<PackDetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      body: CustomScrollView(
        slivers: [
          _buildSliverAppBar(),
          SliverToBoxAdapter(
            child: Column(
              children: [
                _buildPackInfo(),
                _buildFormationsList(),
                _buildPurchaseSection(),
                SizedBox(height: 100),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: widget.pack.isPurchased ? _buildAssistantFAB() : null,
    );
  }

  Widget _buildSliverAppBar() {
    return SliverAppBar(
      expandedHeight: 250,
      floating: false,
      pinned: true,
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: widget.pack.name.contains('Dropskills')
                  ? [Colors.purple, Colors.purple.withOpacity(0.8)]
                  : [Colors.orange, Colors.orange.withOpacity(0.8)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.5),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 20,
                left: 20,
                right: 20,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(AppBorderRadius.sm),
                      ),
                      child: Text(
                        widget.pack.author,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      widget.pack.name,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              if (!widget.pack.isPurchased)
                Center(
                  child: Icon(
                    Icons.lock,
                    color: Colors.white.withOpacity(0.5),
                    size: 80,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPackInfo() {
    return Container(
      margin: EdgeInsets.all(AppSpacing.md),
      padding: EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppBorderRadius.lg),
        border: Border.all(color: Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.star, color: Colors.amber, size: 20),
                        SizedBox(width: 4),
                        Text(
                          widget.pack.rating.toString(),
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                          ),
                        ),
                        SizedBox(width: AppSpacing.md),
                        Icon(Icons.people, color: AppTheme.textSecondary, size: 20),
                        SizedBox(width: 4),
                        Text(
                          '${widget.pack.studentsCount} étudiants',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                    SizedBox(height: AppSpacing.sm),
                    Row(
                      children: [
                        Icon(Icons.video_library, color: AppTheme.textSecondary, size: 20),
                        SizedBox(width: 4),
                        Text(
                          '${widget.pack.formations.length} formations',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                        SizedBox(width: AppSpacing.md),
                        Icon(Icons.access_time, color: AppTheme.textSecondary, size: 20),
                        SizedBox(width: 4),
                        Text(
                          Formatters.formatDuration(widget.pack.totalDuration),
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              if (!widget.pack.isPurchased)
                Text(
                  Formatters.formatAmount(widget.pack.price),
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.accentColor,
                  ),
                ),
            ],
          ),
          SizedBox(height: AppSpacing.lg),
          Text(
            'Description',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          SizedBox(height: AppSpacing.sm),
          Text(
            widget.pack.description,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          SizedBox(height: AppSpacing.lg),
          Container(
            padding: EdgeInsets.all(AppSpacing.md),
            decoration: BoxDecoration(
              color: AppTheme.accentColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(AppBorderRadius.md),
              border: Border.all(color: AppTheme.accentColor.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(Icons.info, color: AppTheme.accentColor),
                SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Text(
                    '15% de cashback à la fin de chaque formation complétée !',
                    style: TextStyle(
                      color: AppTheme.accentColor,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormationsList() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: AppSpacing.md),
      padding: EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppBorderRadius.lg),
        border: Border.all(color: Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Formations incluses',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          SizedBox(height: AppSpacing.lg),
          ...widget.pack.formations.asMap().entries.map((entry) {
            int index = entry.key;
            Formation formation = entry.value;
            return _buildFormationItem(formation, index + 1);
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildFormationItem(Formation formation, int number) {
    final isAccessible = widget.pack.isPurchased;
    final progress = widget.pack.progress[formation.id] ?? 0.0;
    final isCompleted = progress >= 100.0;

    return Container(
      margin: EdgeInsets.only(bottom: AppSpacing.md),
      child: InkWell(
        onTap: isAccessible
            ? () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FormationPlayerScreen(formation: formation),
                  ),
                );
              }
            : null,
        borderRadius: BorderRadius.circular(AppBorderRadius.md),
        child: Container(
          padding: EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            color: isAccessible
                ? (isCompleted ? AppTheme.accentColor.withOpacity(0.05) : Colors.transparent)
                : Colors.grey.withOpacity(0.05),
            borderRadius: BorderRadius.circular(AppBorderRadius.md),
            border: Border.all(
              color: isAccessible
                  ? (isCompleted ? AppTheme.accentColor.withOpacity(0.3) : Color(0xFFE2E8F0))
                  : Colors.grey.withOpacity(0.2),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: isAccessible
                      ? (isCompleted ? AppTheme.accentColor : AppTheme.primaryColor)
                      : Colors.grey,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: isCompleted
                      ? Icon(Icons.check, color: Colors.white, size: 20)
                      : Text(
                          '$number',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                ),
              ),
              SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      formation.title,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: isAccessible ? AppTheme.textPrimary : Colors.grey,
                      ),
                    ),
                    SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.play_circle,
                          size: 14,
                          color: isAccessible ? AppTheme.textSecondary : Colors.grey,
                        ),
                        SizedBox(width: 4),
                        Text(
                          '${formation.modules.length} modules',
                          style: TextStyle(
                            fontSize: 12,
                            color: isAccessible ? AppTheme.textSecondary : Colors.grey,
                          ),
                        ),
                        SizedBox(width: AppSpacing.md),
                        Icon(
                          Icons.access_time,
                          size: 14,
                          color: isAccessible ? AppTheme.textSecondary : Colors.grey,
                        ),
                        SizedBox(width: 4),
                        Text(
                          Formatters.formatDuration(formation.duration),
                          style: TextStyle(
                            fontSize: 12,
                            color: isAccessible ? AppTheme.textSecondary : Colors.grey,
                          ),
                        ),
                      ],
                    ),
                    if (isAccessible && progress > 0) ...[
                      SizedBox(height: AppSpacing.sm),
                      LinearProgressIndicator(
                        value: progress / 100,
                        backgroundColor: Colors.grey[200],
                        valueColor: AlwaysStoppedAnimation<Color>(
                          isCompleted ? AppTheme.accentColor : AppTheme.primaryColor,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (!isAccessible)
                Icon(Icons.lock, color: Colors.grey)
              else if (isCompleted)
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.accentColor,
                    borderRadius: BorderRadius.circular(AppBorderRadius.sm),
                  ),
                  child: Text(
                    'Complété',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPurchaseSection() {
    if (widget.pack.isPurchased) {
      return Container(
        margin: EdgeInsets.all(AppSpacing.md),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(AppSpacing.md),
              decoration: BoxDecoration(
                color: AppTheme.accentColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppBorderRadius.md),
                border: Border.all(color: AppTheme.accentColor.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.check_circle, color: AppTheme.accentColor),
                  SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Pack acheté',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: AppTheme.accentColor,
                          ),
                        ),
                        Text(
                          'Progression: ${widget.pack.completionPercentage.toStringAsFixed(0)}%',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: AppSpacing.md),
            Container(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: () {
                  if (widget.pack.formations.isNotEmpty) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => FormationPlayerScreen(
                          formation: widget.pack.formations.first,
                        ),
                      ),
                    );
                  }
                },
                icon: Icon(Icons.play_arrow),
                label: Text('Continuer l\'apprentissage'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      margin: EdgeInsets.all(AppSpacing.md),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: () => _showPurchaseDialog(),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.accentColor,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.shopping_cart),
                  SizedBox(width: AppSpacing.sm),
                  Text(
                    'Acheter pour ${Formatters.formatAmount(widget.pack.price)}',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: AppSpacing.sm),
          Text(
            'Accès à vie • Certificats inclus • Support disponible',
            style: Theme.of(context).textTheme.bodySmall,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildAssistantFAB() {
    return FloatingActionButton.extended(
      onPressed: _showAssistant,
      backgroundColor: AppTheme.primaryColor,
      icon: Icon(Icons.psychology, color: Colors.white),
      label: Text(
        'Prof IA',
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
      ),
    );
  }

  void _showPurchaseDialog() {
    final walletProvider = Provider.of<WalletProvider>(context, listen: false);
    final canPurchase = walletProvider.balance >= widget.pack.price;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Confirmer l\'achat'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Pack: ${widget.pack.name}'),
            SizedBox(height: AppSpacing.sm),
            Text('Prix: ${Formatters.formatAmount(widget.pack.price)}'),
            SizedBox(height: AppSpacing.sm),
            Text('Solde actuel: ${Formatters.formatAmount(walletProvider.balance)}'),
            SizedBox(height: AppSpacing.md),
            if (!canPurchase)
              Text(
                'Solde insuffisant',
                style: TextStyle(color: AppTheme.errorColor),
              )
            else
              Text(
                'Ce pack sera ajouté à votre bibliothèque avec un accès à vie.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Annuler'),
          ),
          ElevatedButton(
            onPressed: canPurchase ? () => _processPurchase() : null,
            child: Text('Confirmer'),
          ),
        ],
      ),
    );
  }

  void _processPurchase() async {
    Navigator.pop(context);
    
    final formationProvider = Provider.of<FormationProvider>(context, listen: false);
    final success = await formationProvider.purchasePack(widget.pack.id);
    
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Pack acheté avec succès !'),
          backgroundColor: AppTheme.accentColor,
        ),
      );
      setState(() {});
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur lors de l\'achat'),
          backgroundColor: AppTheme.errorColor,
        ),
      );
    }
  }

  void _showAssistant() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AIAssistantModal(
        packName: widget.pack.name,
      ),
    );
  }
}